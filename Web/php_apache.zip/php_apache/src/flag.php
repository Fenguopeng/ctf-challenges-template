<?php
$flag = "flag{}";
?>